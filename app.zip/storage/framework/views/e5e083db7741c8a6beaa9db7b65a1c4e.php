

<?php $__env->startSection('content'); ?>

<h2>Documentation</h2>

<h4>Laravel Socialite Package</h4>

<h5 data-bs-toggle="tooltip" data-placement="top" title="Tooltip on top">Installation</h5>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\wamp64\www\Zayed\Projects\all_in_one\resources\views/documentation/index.blade.php ENDPATH**/ ?>